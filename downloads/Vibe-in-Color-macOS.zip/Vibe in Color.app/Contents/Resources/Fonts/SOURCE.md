# Bundled font assets

## Victor Mono

- Family: Victor Mono
- Version: 1.561
- Source: https://github.com/google/fonts/tree/0e024e829ae21f36a19ceb2ecd72a2bbd1b72508/ofl/victormono
- Source revision: `0e024e829ae21f36a19ceb2ecd72a2bbd1b72508`
- Variable TTF SHA-256: `6fab3abe37b456f56d180987e04a3a0c326bace2cb825bc638b6be1eb03edf8f`
- License: SIL Open Font License 1.1, reproduced in `VictorMono-OFL.txt`

The app uses the unmodified variable TTF distributed by Google Fonts. Its Light, Regular, and Medium instances provide the complete interface hierarchy, including the vibe stage.

## Intel One Mono

- Family: Intel One Mono
- Version: 1.4.0
- Source: https://github.com/intel/intel-one-mono/releases/tag/V1.4.0
- Archive: `ttf.zip`
- Archive SHA-256: `54863552d25dcb9c3f5360b296fc980d6e1fbfd02e0d214224e8b78f0a2bccf0`
- License: SIL Open Font License 1.1, reproduced in `OFL.txt`

The app includes the unmodified Regular, Medium, and Bold TTF files from the official release archive.

## Inconsolata

- Family: Inconsolata
- Source: https://github.com/google/fonts/tree/0b58fb370093f9a9f4ff785d94405710b79de67c/ofl/inconsolata
- Light SHA-256: `5b56d22fc7e536a3f2932dfa726cccfa12632be6ffdcc2fa97e053af49a4b844`
- Regular SHA-256: `0f11ac40d1618e1aa1adb7322a14980a0b0c943421124022073f83236d15f0d5`
- License: SIL Open Font License 1.1, reproduced in `Inconsolata-OFL.txt`

These files remain available for theme font previews but are no longer part of the app's interface typography.
